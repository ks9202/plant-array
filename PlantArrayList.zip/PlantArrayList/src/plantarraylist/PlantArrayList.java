/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantarraylist;
import java.util.Scanner;
import java.util.ArrayList;
import javax.swing.JFrame;
// import java.util.StringTokenizer;
/**
 *
 * @author kkimh
 */
public class PlantArrayList {

   // Prints an ArrayList of plant (or flower) objects
   public static void printArrayList(ArrayList<Plant> myGarden)
   {
      int i;
      for (i = 0; i < myGarden.size(); ++i)
      {
         System.out.println("Plant " + (i+1) + " Information: ");
         myGarden.get(i).printInfo();
         System.out.println();
      }
   }
   
   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);
      String input;
      // Declares an ArrayList called myGarden that can hold object of type plant
      ArrayList<Plant> myGarden = new ArrayList<>();

      // Variables
      String plantName, plantCost, flowerName, flowerCost, colorOfFlowers;
      boolean isAnnual;
      String placeholder;
      Plant currPlant;
      Flower currFlower;
      
      // Starts GUI to select plant or flower.
      // Rest of program below runs text based and not in GUI, needs to be moved to GUI
      PlantOrFlowerGUI myFrame = new PlantOrFlowerGUI();
      myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      myFrame.pack();
      myFrame.setVisible(true);
      
      
      input = scnr.next();
      while(!input.equals("-1")){
         //       Check if input is a plant or flower
         //       Store as a plant object or flower object
         //       Add to the ArrayList myGarden
         
         if (input.equals("plant"))
         {
            plantName = scnr.next();
            plantCost = scnr.next();
            
            currPlant = new Plant();
            currPlant.setPlantName(plantName);
            currPlant.setPlantCost(plantCost);
            myGarden.add(currPlant);
         }
         else if (input.equals("flower"))
         {
            flowerName = scnr.next();
            flowerCost = scnr.next();
            placeholder = scnr.next();
            isAnnual = Boolean.valueOf(placeholder);
            colorOfFlowers = scnr.next();
            
            currFlower = new Flower();
            currFlower.setPlantName(flowerName);
            currFlower.setPlantCost(flowerCost);
            currFlower.setPlantType(isAnnual);
            currFlower.setColorOfFlowers(colorOfFlowers);
            myGarden.add(currFlower);
         }
      
         input = scnr.next();
      }
      
      // Calls the method printArrayList to print myGarden
      printArrayList(myGarden);
   }
}
