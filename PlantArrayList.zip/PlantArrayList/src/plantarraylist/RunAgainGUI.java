/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantarraylist;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

/**
 *
 * @author kkimh
 */
public class RunAgainGUI extends JFrame implements ActionListener {
    private JLabel messageLabel; // Message
    private JButton yesButton;
    private JButton noButton;
    
    RunAgainGUI() {
        
        // Constructor creates and adds GUI components
        GridBagConstraints layoutConst = null;
        
        // Frame title
        setTitle("Confirmation");
        
        // Message prompt
        messageLabel = new JLabel("Do you have any more entries?\n Click No to exit.");
        
        // Buttons
        yesButton = new JButton("Yes");
        yesButton.addActionListener(this);
        
        noButton = new JButton("No");
        noButton.addActionListener(this);
        
        // Message label layout
        setLayout(new GridBagLayout());
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 0;
        layoutConst.gridy = 0;
        layoutConst.insets = new Insets(50, 100, 20, 20);
        add(messageLabel, layoutConst);
        
        // Next button layout
        layoutConst = new GridBagConstraints();
        layoutConst.insets = new Insets(0, 10, 10, 5);
        layoutConst.fill = GridBagConstraints.HORIZONTAL;
        layoutConst.gridx = 4;
        layoutConst.gridy = 4;
        add(yesButton, layoutConst);
        
        // Quit button layout
        layoutConst = new GridBagConstraints();
        layoutConst.insets = new Insets(0, 5, 10, 10);
        layoutConst.fill = GridBagConstraints.HORIZONTAL;
        layoutConst.gridx = 5;
        layoutConst.gridy = 4;
        add(noButton, layoutConst);
    }
    
    // Called on event
    @Override
    public void actionPerformed(ActionEvent event) {
        
        // Get source of event
        JButton sourceEvent = (JButton) event.getSource();
        
        if (sourceEvent == yesButton)
        {
            // If yes button clicked
            dispose();
            PlantOrFlowerGUI myFrame = new PlantOrFlowerGUI();
            myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            myFrame.pack();
            myFrame.setVisible(true);
        }
        else if (sourceEvent == noButton)
        {
            // No button clicked
            // TODO Print array to file
            dispose(); // Close window
        }
    }
}