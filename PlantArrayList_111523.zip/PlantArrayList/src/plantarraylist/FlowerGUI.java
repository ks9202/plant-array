/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantarraylist;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JRadioButton;

/**
 *
 * @author kkimh
 */
public class FlowerGUI extends JFrame implements ActionListener {
    private JLabel flowerNameL; // Label for plant name
    private JTextField flowerNameField; // Field for plant name
    private JLabel flowerCostL;
    private JTextField flowerCostField;
    private JLabel annualL;
    private JRadioButton trueButton;
    private JRadioButton falseButton;
    private JLabel colorL;
    
    private JButton nextButton;
    private JButton quitButton;
    
    FlowerGUI() {
        
        // Constructor creates and adds GUI components
        GridBagConstraints layoutConst = null;
        
        // Frame title
        setTitle("Flower");
        
        flowerNameL = new JLabel("Flower name:");
        flowerCostL = new JLabel("Flower cost:");
        annualL = new JLabel("Annual:");
        colorL = new JLabel("Color:");
        
        // Set plant or flower field
        flowerNameField = new JTextField(15);
        flowerNameField.setEditable(true);
        flowerNameField.addActionListener(this);
        
        flowerCostField = new JTextField(5);
        flowerCostField.setEditable(true);
        flowerCostField.addActionListener(this);
        
        // Radio buttons
        trueButton = new JRadioButton("True");
        falseButton = new JRadioButton("False");
        
        // Buttons
        nextButton = new JButton("Next");
        nextButton.addActionListener(this);
        
        quitButton = new JButton("Quit");
        quitButton.addActionListener(this);
        
        // TODO: Fix layout of controls below
        
        // Flower name label layout
        setLayout(new GridBagLayout());
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 0;
        layoutConst.gridy = 0;
        layoutConst.insets = new Insets(10, 10, 10, 10);
        layoutConst.gridwidth = 2;
        add(flowerNameL, layoutConst);
        
        // Flower cost label
        setLayout(new GridBagLayout());
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 0;
        layoutConst.gridy = 1;
        layoutConst.insets = new Insets(10, 10, 10, 10);
        add(flowerCostL, layoutConst);
        
        // Annual label
        setLayout(new GridBagLayout());
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 0;
        layoutConst.gridy = 2;
        layoutConst.insets = new Insets(10, 10, 10, 10);
        add(annualL, layoutConst);
        
        // Color label
        setLayout(new GridBagLayout());
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 0;
        layoutConst.gridy = 3;
        layoutConst.insets = new Insets(10, 10, 10, 10);
        add(colorL, layoutConst);
        
        // Plant name field layout
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 1;
        layoutConst.gridy = 0;
        layoutConst.insets = new Insets(10, 10, 10, 10);
        add(flowerNameField, layoutConst);
        
        // Plant cost field layout
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 1;
        layoutConst.gridy = 1;
        layoutConst.insets = new Insets(10, 10, 10, 10);
        add(flowerCostField, layoutConst);
        
        // Radio buttons field layout
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 1;
        layoutConst.gridy = 2;
        layoutConst.insets = new Insets(10, 10, 20, 20);
        add(trueButton, layoutConst);
        
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 2;
        layoutConst.gridy = 2;
        layoutConst.insets = new Insets(10, 10, 20, 20);
        add(falseButton, layoutConst);
        
        // Next button layout
        layoutConst = new GridBagConstraints();
        layoutConst.insets = new Insets(0, 10, 10, 5);
        layoutConst.fill = GridBagConstraints.HORIZONTAL;
        layoutConst.gridx = 4;
        layoutConst.gridy = 4;
        add(nextButton, layoutConst);
        
        // Quit button layout
        layoutConst = new GridBagConstraints();
        layoutConst.insets = new Insets(0, 5, 10, 10);
        layoutConst.fill = GridBagConstraints.HORIZONTAL;
        layoutConst.gridx = 5;
        layoutConst.gridy = 4;
        add(quitButton, layoutConst);
    }
    
    // Called on event
    @Override
    public void actionPerformed(ActionEvent event) {
        
        // Get source of event
        JButton sourceEvent = (JButton) event.getSource();
        
        if (sourceEvent == nextButton)
        {
            // TODO Add input validation
            
            // If next button clicked
            dispose();
            RunAgainGUI myFrame = new RunAgainGUI();
            myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            myFrame.pack();
            myFrame.setVisible(true);
        }
        else if (sourceEvent == quitButton)
        {
            System.exit(0); // Terminate program
        }
    }
}