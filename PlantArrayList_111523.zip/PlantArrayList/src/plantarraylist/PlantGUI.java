/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantarraylist;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author kkimh
 */
public class PlantGUI extends JFrame implements ActionListener {
    private JLabel plantNameL; // Label for plant name
    private JTextField plantNameField; // Field for plant name
    private JLabel plantCostL;
    private JTextField plantCostField;
    private JButton nextButton;
    private JButton quitButton;
    
    PlantGUI() {
        
        // Constructor creates and adds GUI components
        GridBagConstraints layoutConst = null;
        
        // Frame title
        setTitle("Plant");
        
        plantNameL = new JLabel("Plant name:");
        plantCostL = new JLabel("Plant cost:");
        
        // Set plant or flower field
        plantNameField = new JTextField(15);
        plantNameField.setEditable(true);
        plantNameField.addActionListener(this);
        
        plantCostField = new JTextField(5);
        plantCostField.setEditable(true);
        plantCostField.addActionListener(this);
        
        // Buttons
        nextButton = new JButton("Next");
        nextButton.addActionListener(this);
        
        quitButton = new JButton("Quit");
        quitButton.addActionListener(this);
        
        // Plant choice label layout
        setLayout(new GridBagLayout());
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 0;
        layoutConst.gridy = 0;
        layoutConst.insets = new Insets(10, 50, 50, 50);
        add(plantNameL, layoutConst);
        
        // Plant cost label
        setLayout(new GridBagLayout());
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 0;
        layoutConst.gridy = 1;
        layoutConst.insets = new Insets(10, 50, 50, 50);
        add(plantCostL, layoutConst);
        
        // Plant name field layout
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 1;
        layoutConst.gridy = 0;
        layoutConst.insets = new Insets(50, 50, 50, 50);
        add(plantNameField, layoutConst);
        
        // Plant cost field layout
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 1;
        layoutConst.gridy = 1;
        layoutConst.insets = new Insets(10, 50, 50, 50);
        add(plantCostField, layoutConst);
        
        // Next button layout
        layoutConst = new GridBagConstraints();
        layoutConst.insets = new Insets(0, 10, 10, 5);
        layoutConst.fill = GridBagConstraints.HORIZONTAL;
        layoutConst.gridx = 4;
        layoutConst.gridy = 4;
        add(nextButton, layoutConst);
        
        // Quit button layout
        layoutConst = new GridBagConstraints();
        layoutConst.insets = new Insets(0, 5, 10, 10);
        layoutConst.fill = GridBagConstraints.HORIZONTAL;
        layoutConst.gridx = 5;
        layoutConst.gridy = 4;
        add(quitButton, layoutConst);
    }
    
    // Called on event
    @Override
    public void actionPerformed(ActionEvent event) {
        
        // Get source of event
        JButton sourceEvent = (JButton) event.getSource();
        
        if (sourceEvent == nextButton)
        {
            // Input validation
            if (plantNameField.getText().equals("") || plantCostField.getText().equals(""))
            {
                JOptionPane.showMessageDialog(null, "Please enter both a valid plant name and cost.");
            }
            else
            {
                // Moves to next page when input is valid
                dispose();
                RunAgainGUI myFrame = new RunAgainGUI();
                myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                myFrame.pack();
                myFrame.setVisible(true);
            }
        }
        else if (sourceEvent == quitButton)
        {
            System.exit(0); // Terminate program
        }
    }
}