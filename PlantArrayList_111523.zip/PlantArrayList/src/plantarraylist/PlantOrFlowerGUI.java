/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plantarraylist;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JOptionPane;

/**
 *
 * @author kkimh
 */
public class PlantOrFlowerGUI extends JFrame implements ActionListener {
    private JLabel plantChoice; // Label for plant or flower selection
    private JButton nextButton;
    private JButton quitButton;
    private JRadioButton plantButton;
    private JRadioButton flowerButton;
    
    PlantOrFlowerGUI() {
        
        // Constructor creates and adds GUI components
        GridBagConstraints layoutConst = null;
        
        // Frame title
        setTitle("Plant List Printer");
        
        plantChoice = new JLabel("Plant or flower?:");
        
        // Buttons
        nextButton = new JButton("Next");
        nextButton.addActionListener(this);
        
        quitButton = new JButton("Quit");
        quitButton.addActionListener(this);
        
        // Radio buttons
        plantButton = new JRadioButton("Plant");
        flowerButton = new JRadioButton("Flower");
        
        // Plant choice label layout
        setLayout(new GridBagLayout());
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 0;
        layoutConst.gridy = 0;
        layoutConst.insets = new Insets(50, 100, 20, 20);
        add(plantChoice, layoutConst);
        
        // Plant button
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 1;
        layoutConst.gridy = 0;
        layoutConst.insets = new Insets(50, 50, 20, 20);
        add(plantButton, layoutConst);
        
        // Flower button
        layoutConst = new GridBagConstraints();
        layoutConst.gridx = 2;
        layoutConst.gridy = 0;
        layoutConst.insets = new Insets(50, 50, 20, 20);
        add(flowerButton, layoutConst);
        
        // Next button layout
        layoutConst = new GridBagConstraints();
        layoutConst.insets = new Insets(0, 10, 10, 5);
        layoutConst.fill = GridBagConstraints.HORIZONTAL;
        layoutConst.gridx = 4;
        layoutConst.gridy = 4;
        add(nextButton, layoutConst);
        
        // Quit button layout
        layoutConst = new GridBagConstraints();
        layoutConst.insets = new Insets(0, 5, 10, 10);
        layoutConst.fill = GridBagConstraints.HORIZONTAL;
        layoutConst.gridx = 5;
        layoutConst.gridy = 4;
        add(quitButton, layoutConst);
    }
    
    // Called on event
    @Override
    public void actionPerformed(ActionEvent event) {
        // Get source of event
        JButton sourceEvent = (JButton) event.getSource();
        
        if (sourceEvent == nextButton)
        {
            // Close current window and open next window
            if (plantButton.isSelected())
            {
                // Closes current frame and opens GUI for plant information
                dispose();
                PlantGUI myFrame = new PlantGUI();
                myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                myFrame.pack();
                myFrame.setVisible(true);
            }
            else if (flowerButton.isSelected())
            {
                // Closes current frame and opens GUI for flower information
                dispose();
                FlowerGUI myFrame = new FlowerGUI();
                myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                myFrame.pack();
                // myFrame.setSize(900, 700);
                myFrame.setVisible(true);
            }
            else
            {
                // User has not selected either option
                JOptionPane.showMessageDialog(null, "Please select plant or flower.");
            }
        }
        else if (sourceEvent == quitButton)
        {
            System.exit(0); // Closes window
        }
    }
}
